package workshop;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class login 
{

	public static void main(String[] args) throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","E:\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=900&openid.return_to=https%3A%2F%2Fwww.amazon.in%2Fgp%2Fyourstore%2Fhome%3Fpath%3D%252Fgp%252Fyourstore%252Fhome%26useRedirectOnSuccess%3D1%26signIn%3D1%26action%3Dsign-out%26ref_%3Dnav_AccountFlyout_signout&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0");
		driver.findElement(By.id("continue")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("ap_email")).sendKeys("@@#$%%^&^%$##$%^&");
		Thread.sleep(5000);
		driver.findElement(By.id("continue")).click();
		Thread.sleep(5000);
		driver.findElement(By.id("ap_email")).clear();
		Thread.sleep(5000);
        driver.findElement(By.id("continue")).click();
		driver.findElement(By.id("ap_email")).sendKeys("behappy19999@gmail.com");
		Thread.sleep(5000);
        driver.findElement(By.id("continue")).click();
        driver.findElement(By.id("ap_password")).sendKeys("Behappy19999@");
        Thread.sleep(5000);
        driver.findElement(By.id("signInSubmit")).click();
       //System.out.println(driver.getTitle());
       String b = "Amazon Sign In";
       String a = driver.getTitle();
       if(a.equalsIgnoreCase(b))
       {
        	System.out.println("Test Successful");
        }
       else
       {
       	    System.out.println("Test Not Successful");	
       }
        
	}

}
